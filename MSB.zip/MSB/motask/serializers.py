from django.db import models
from rest_framework import serializers
from motask.models import Stock
#Serializing my model 

class StockSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stock
        fields = "__all__"

