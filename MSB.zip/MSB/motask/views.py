#i then created the logic/api
from django.shortcuts import render
from rest_framework.generics import ListAPIView
from rest_framework.generics import CreateAPIView
from rest_framework.generics import DestroyAPIView
from rest_framework.generics import UpdateAPIView
from motask.models import Stock

from motask.serializers import StockSerializer


class ListStockAPIView(ListAPIView):
    """This endpoint list all of the available todos from the database"""
    queryset = Stock.objects.all()
    serializer_class = StockSerializer

class CreateStockAPIView(CreateAPIView):
    """endpoint to create stock"""
    queryset = Stock.objects.all()
    serializer_class = StockSerializer


class UpdateStockAPIView(UpdateAPIView):
    """endpoint to update stock"""
    queryset = Stock.objects.all()
    serializer_class = StockSerializer

class DeleteStockAPIView(DestroyAPIView):
    """endpoint to delete stock"""
    queryset = Stock.objects.all()
    serializer_class = StockSerializer

 
