#I then created my model and migrated it

from django.db import models

# Create your models here.
from django.db import models

# My mmodel. Make migrations after, then migrate
from django.db import models

# Create your models here.
class Stock(models.Model):
    Status_choice =(
        ('Pending', 'Pending'),
        ('Published', 'Published'),
    )
    stock_name = models.CharField(max_length=100, blank=True)
    Quantity = models.IntegerField(blank=True, null=True)
    Status = models.CharField(max_length=50, choices=Status_choice)
    datetime = models.DateTimeField(auto_now=True) 

    def __str__(self):
        return self.title 