from django.urls import path
from motask import views

urlpatterns = [
    path("",views.ListStockAPIView.as_view(),name="stock_list"),
    path("create/", views.CreateStockAPIView.as_view(),name="stock_create"),
    path("update/<int:pk>/",views.UpdateStockAPIView.as_view(),name="update_stock"),
    path("delete/<int:pk>/",views.DeleteStockAPIView.as_view(),name="delete_stock")
]